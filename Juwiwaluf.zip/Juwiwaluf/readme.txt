
Try first: Juwiwaluf.exe

If error, go to VC folder and install: vc_redist.x86.exe

Try again.

=============================================================

JuwIwaluf (Just-what-I-was-looking-for) is a simple game.

The board:

9 rows and 6 columns.

Introduction:

The bottom two rows are the "dice".
The top row records the results of obtaining a double.
The rows in between are the credits (6 per columns)

The goal of the game is to obtains all six doubles without
exhausting the credits at any one column.

How to play:

The player controls the game using the keyboard.

Arrow Keys:

Up -- roll the two dice.
Left -- roll the "buttom" die.
Right -- roll the "top" die.
Down -- abort a turn.

Spacebar:

re-arrange credits on the board.

Escape:

Quit the game.

=============================================================
The rules:

The play starts by playing the two dice (up arrow).
If a double is obtained, the top row records the results by
changing color at the location of the corresponding double.
No credit is lost.

If a double is not obtained, the player can choose between:
playing the two dice again (up arrow),
playing the bottom die (left arrow),
playing the top die (right arrow),
aborting the turn (down arrow).

If a double is obtained, the result is recorded and
no credits is lost.

If a double is not obtained, two credits are lost (one for
each roll).

Aborting the turn also loses two credits.

One credit is lost if a double is obtained another time.

the player is allowed to re-order the credits before a turn
by pressing the spacebar.

The game ends when:
all six doubles are obtained (win)
at least one column has no credits left (lost)
the player press the "escape" key and quit the game.

=============================================================
Disclaimer: 
This is a demo program used by resposible people only.
=============================================================

Normand M. Blais, Dec 2016

